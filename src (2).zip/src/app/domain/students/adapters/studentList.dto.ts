export interface StudentListDTO {
    students: {
      id: number;
      name: string;
      email: string;
      career: string;
      matricula: string;
    }[];
  }
  