export class Student {
    constructor(
      public ID: number,
      public Name: string,
      public Email: string,
      public Career: string,
      public Matricula: string
    ) {}
  }
  